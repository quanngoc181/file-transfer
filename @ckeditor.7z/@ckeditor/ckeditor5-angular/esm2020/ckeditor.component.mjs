import { Component, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { EditorWatchdog } from '@ckeditor/ckeditor5-watchdog';
import { first } from 'rxjs/operators';
import uid from './uid';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i0 from "@angular/core";
const ANGULAR_INTEGRATION_READ_ONLY_LOCK_ID = 'Lock from Angular integration (@ckeditor/ckeditor5-angular)';
export class CKEditorComponent {
    constructor(elementRef, ngZone) {
        /**
         * The configuration of the editor.
         * See https://ckeditor.com/docs/ckeditor5/latest/api/module_core_editor_editorconfig-EditorConfig.html
         * to learn more.
         */
        this.config = {};
        /**
         * The initial data of the editor. Useful when not using the ngModel.
         * See https://angular.io/api/forms/NgModel to learn more.
         */
        this.data = '';
        /**
         * Tag name of the editor component.
         *
         * The default tag is 'div'.
         */
        this.tagName = 'div';
        /**
         * Allows disabling the two-way data binding mechanism. Disabling it can boost performance for large documents.
         *
         * When a component is connected using the [(ngModel)] or [formControl] directives and this value is set to true then none of the data
         * will ever be synchronized.
         *
         * An integrator must call `editor.data.get()` manually once the application needs the editor's data.
         * An editor instance can be received in the `ready()` callback.
         */
        this.disableTwoWayDataBinding = false;
        /**
         * Fires when the editor is ready. It corresponds with the `editor#ready`
         * https://ckeditor.com/docs/ckeditor5/latest/api/module_core_editor_editor-Editor.html#event-ready
         * event.
         */
        this.ready = new EventEmitter();
        /**
         * Fires when the content of the editor has changed. It corresponds with the `editor.model.document#change`
         * https://ckeditor.com/docs/ckeditor5/latest/api/module_engine_model_document-Document.html#event-change
         * event.
         */
        this.change = new EventEmitter();
        /**
         * Fires when the editing view of the editor is blurred. It corresponds with the `editor.editing.view.document#blur`
         * https://ckeditor.com/docs/ckeditor5/latest/api/module_engine_view_document-Document.html#event-event:blur
         * event.
         */
        this.blur = new EventEmitter();
        /**
         * Fires when the editing view of the editor is focused. It corresponds with the `editor.editing.view.document#focus`
         * https://ckeditor.com/docs/ckeditor5/latest/api/module_engine_view_document-Document.html#event-event:focus
         * event.
         */
        this.focus = new EventEmitter();
        /**
         * Fires when the editor component crashes.
         */
        this.error = new EventEmitter();
        /**
         * If the component is read–only before the editor instance is created, it remembers that state,
         * so the editor can become read–only once it is ready.
         */
        this.initiallyDisabled = false;
        /**
         * A lock flag preventing from calling the `cvaOnChange()` during setting editor data.
         */
        this.isEditorSettingData = false;
        this.id = uid();
        this.ngZone = ngZone;
        this.elementRef = elementRef;
        // To avoid issues with the community typings and CKEditor 5, let's treat window as any. See #342.
        const { CKEDITOR_VERSION } = window;
        if (CKEDITOR_VERSION) {
            const [major] = CKEDITOR_VERSION.split('.').map(Number);
            if (major < 37) {
                console.warn('The <CKEditor> component requires using CKEditor 5 in version 37 or higher.');
            }
        }
        else {
            console.warn('Cannot find the "CKEDITOR_VERSION" in the "window" scope.');
        }
    }
    /**
     * When set `true`, the editor becomes read-only.
     * See https://ckeditor.com/docs/ckeditor5/latest/api/module_core_editor_editor-Editor.html#member-isReadOnly
     * to learn more.
     */
    set disabled(isDisabled) {
        this.setDisabledState(isDisabled);
    }
    get disabled() {
        if (this.editorInstance) {
            return this.editorInstance.isReadOnly;
        }
        return this.initiallyDisabled;
    }
    /**
     * The instance of the editor created by this component.
     */
    get editorInstance() {
        let editorWatchdog = this.editorWatchdog;
        if (this.watchdog) {
            // Temporarily use the `_watchdogs` internal map as the `getItem()` method throws
            // an error when the item is not registered yet.
            // See https://github.com/ckeditor/ckeditor5-angular/issues/177.
            // TODO should be able to change when new chages in Watcdog are released.
            editorWatchdog = this.watchdog._watchdogs.get(this.id);
        }
        if (editorWatchdog) {
            return editorWatchdog.editor;
        }
        return null;
    }
    getId() {
        return this.id;
    }
    // Implementing the OnChanges interface. Whenever the `data` property is changed, update the editor content.
    ngOnChanges(changes) {
        if (Object.prototype.hasOwnProperty.call(changes, 'data') && changes.data && !changes.data.isFirstChange()) {
            this.writeValue(changes.data.currentValue);
        }
    }
    // Implementing the AfterViewInit interface.
    ngAfterViewInit() {
        this.attachToWatchdog();
    }
    // Implementing the OnDestroy interface.
    async ngOnDestroy() {
        if (this.watchdog) {
            await this.watchdog.remove(this.id);
        }
        else if (this.editorWatchdog && this.editorWatchdog.editor) {
            await this.editorWatchdog.destroy();
            this.editorWatchdog = undefined;
        }
    }
    // Implementing the ControlValueAccessor interface (only when binding to ngModel).
    writeValue(value) {
        // This method is called with the `null` value when the form resets.
        // A component's responsibility is to restore to the initial state.
        if (value === null) {
            value = '';
        }
        // If already initialized.
        if (this.editorInstance) {
            // The lock mechanism prevents from calling `cvaOnChange()` during changing
            // the editor state. See #139
            this.isEditorSettingData = true;
            this.editorInstance.data.set(value);
            this.isEditorSettingData = false;
        }
        // If not, wait for it to be ready; store the data.
        else {
            // If the editor element is already available, then update its content.
            this.data = value;
            // If not, then wait until it is ready
            // and change data only for the first `ready` event.
            this.ready
                .pipe(first())
                .subscribe(editor => {
                editor.data.set(this.data);
            });
        }
    }
    // Implementing the ControlValueAccessor interface (only when binding to ngModel).
    registerOnChange(callback) {
        this.cvaOnChange = callback;
    }
    // Implementing the ControlValueAccessor interface (only when binding to ngModel).
    registerOnTouched(callback) {
        this.cvaOnTouched = callback;
    }
    // Implementing the ControlValueAccessor interface (only when binding to ngModel).
    setDisabledState(isDisabled) {
        // If already initialized.
        if (this.editorInstance) {
            if (isDisabled) {
                this.editorInstance.enableReadOnlyMode(ANGULAR_INTEGRATION_READ_ONLY_LOCK_ID);
            }
            else {
                this.editorInstance.disableReadOnlyMode(ANGULAR_INTEGRATION_READ_ONLY_LOCK_ID);
            }
        }
        // Store the state anyway to use it once the editor is created.
        this.initiallyDisabled = isDisabled;
    }
    /**
     * Creates the editor instance, sets initial editor data, then integrates
     * the editor with the Angular component. This method does not use the `editor.data.set()`
     * because of the issue in the collaboration mode (#6).
     */
    attachToWatchdog() {
        // TODO: elementOrData parameter type can be simplified to HTMLElemen after templated Watchdog will be released.
        const creator = ((elementOrData, config) => {
            return this.ngZone.runOutsideAngular(async () => {
                this.elementRef.nativeElement.appendChild(elementOrData);
                const editor = await this.editor.create(elementOrData, config);
                if (this.initiallyDisabled) {
                    editor.enableReadOnlyMode(ANGULAR_INTEGRATION_READ_ONLY_LOCK_ID);
                }
                this.ngZone.run(() => {
                    this.ready.emit(editor);
                });
                this.setUpEditorEvents(editor);
                return editor;
            });
        });
        const destructor = async (editor) => {
            await editor.destroy();
            this.elementRef.nativeElement.removeChild(this.editorElement);
        };
        const emitError = (e) => {
            // Do not run change detection by re-entering the Angular zone if the `error`
            // emitter doesn't have any subscribers.
            // Subscribers are pushed onto the list whenever `error` is listened inside the template:
            // `<ckeditor (error)="onError(...)"></ckeditor>`.
            if (hasObservers(this.error)) {
                this.ngZone.run(() => this.error.emit(e));
            }
        };
        const element = document.createElement(this.tagName);
        const config = this.getConfig();
        this.editorElement = element;
        // Based on the presence of the watchdog decide how to initialize the editor.
        if (this.watchdog) {
            // When the context watchdog is passed add the new item to it based on the passed configuration.
            this.watchdog.add({
                id: this.id,
                type: 'editor',
                creator,
                destructor,
                sourceElementOrData: element,
                config
            }).catch(e => {
                emitError(e);
            });
            this.watchdog.on('itemError', (_, { itemId }) => {
                if (itemId === this.id) {
                    emitError();
                }
            });
        }
        else {
            // In the other case create the watchdog by hand to keep the editor running.
            const editorWatchdog = new EditorWatchdog(this.editor, this.editorWatchdogConfig);
            editorWatchdog.setCreator(creator);
            editorWatchdog.setDestructor(destructor);
            editorWatchdog.on('error', emitError);
            this.editorWatchdog = editorWatchdog;
            this.ngZone.runOutsideAngular(() => {
                // Note: must be called outside of the Angular zone too because `create` is calling
                // `_startErrorHandling` within a microtask which sets up `error` listener on the window.
                editorWatchdog.create(element, config).catch(e => {
                    emitError(e);
                });
            });
        }
    }
    getConfig() {
        if (this.data && this.config.initialData) {
            throw new Error('Editor data should be provided either using `config.initialData` or `data` properties.');
        }
        const config = { ...this.config };
        // Merge two possible ways of providing data into the `config.initialData` field.
        const initialData = this.config.initialData || this.data;
        if (initialData) {
            // Define the `config.initialData` only when the initial content is specified.
            config.initialData = initialData;
        }
        return config;
    }
    /**
     * Integrates the editor with the component by attaching related event listeners.
     */
    setUpEditorEvents(editor) {
        const modelDocument = editor.model.document;
        const viewDocument = editor.editing.view.document;
        modelDocument.on('change:data', evt => {
            this.ngZone.run(() => {
                if (this.disableTwoWayDataBinding) {
                    return;
                }
                if (this.cvaOnChange && !this.isEditorSettingData) {
                    const data = editor.data.get();
                    this.cvaOnChange(data);
                }
                this.change.emit({ event: evt, editor });
            });
        });
        viewDocument.on('focus', evt => {
            this.ngZone.run(() => {
                this.focus.emit({ event: evt, editor });
            });
        });
        viewDocument.on('blur', evt => {
            this.ngZone.run(() => {
                if (this.cvaOnTouched) {
                    this.cvaOnTouched();
                }
                this.blur.emit({ event: evt, editor });
            });
        });
    }
}
CKEditorComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CKEditorComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component });
CKEditorComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.4.0", type: CKEditorComponent, selector: "ckeditor", inputs: { editor: "editor", config: "config", data: "data", tagName: "tagName", watchdog: "watchdog", editorWatchdogConfig: "editorWatchdogConfig", disableTwoWayDataBinding: "disableTwoWayDataBinding", disabled: "disabled" }, outputs: { ready: "ready", change: "change", blur: "blur", focus: "focus", error: "error" }, providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            // eslint-disable-next-line @typescript-eslint/no-use-before-define
            useExisting: forwardRef(() => CKEditorComponent),
            multi: true
        }
    ], usesOnChanges: true, ngImport: i0, template: '<ng-template></ng-template>', isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CKEditorComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ckeditor',
                    template: '<ng-template></ng-template>',
                    // Integration with @angular/forms.
                    providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            // eslint-disable-next-line @typescript-eslint/no-use-before-define
                            useExisting: forwardRef(() => CKEditorComponent),
                            multi: true
                        }
                    ]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }]; }, propDecorators: { editor: [{
                type: Input
            }], config: [{
                type: Input
            }], data: [{
                type: Input
            }], tagName: [{
                type: Input
            }], watchdog: [{
                type: Input
            }], editorWatchdogConfig: [{
                type: Input
            }], disableTwoWayDataBinding: [{
                type: Input
            }], disabled: [{
                type: Input
            }], ready: [{
                type: Output
            }], change: [{
                type: Output
            }], blur: [{
                type: Output
            }], focus: [{
                type: Output
            }], error: [{
                type: Output
            }] } });
function hasObservers(emitter) {
    // Cast to `any` because `observed` property is available in RxJS >= 7.2.0.
    // Fallback to checking `observers` list if this property is not defined.
    return emitter.observed || emitter.observers.length > 0;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2tlZGl0b3IuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2NrZWRpdG9yL2NrZWRpdG9yLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFPQSxPQUFPLEVBQ04sU0FBUyxFQUNULEtBQUssRUFDTCxNQUFNLEVBRU4sWUFBWSxFQUNaLFVBQVUsRUFFVixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQW1CLGNBQWMsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBTS9FLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUV2QyxPQUFPLEdBQUcsTUFBTSxPQUFPLENBQUM7QUFJeEIsT0FBTyxFQUNOLGlCQUFpQixFQUNqQixNQUFNLGdCQUFnQixDQUFDOztBQUV4QixNQUFNLHFDQUFxQyxHQUFHLDZEQUE2RCxDQUFDO0FBK0I1RyxNQUFNLE9BQU8saUJBQWlCO0lBK0s3QixZQUFvQixVQUFzQixFQUFFLE1BQWM7UUFuSzFEOzs7O1dBSUc7UUFDYSxXQUFNLEdBQWlCLEVBQUUsQ0FBQztRQUUxQzs7O1dBR0c7UUFDYSxTQUFJLEdBQUcsRUFBRSxDQUFDO1FBRTFCOzs7O1dBSUc7UUFDYSxZQUFPLEdBQUcsS0FBSyxDQUFDO1FBYWhDOzs7Ozs7OztXQVFHO1FBQ2EsNkJBQXdCLEdBQUcsS0FBSyxDQUFDO1FBbUJqRDs7OztXQUlHO1FBQ2MsVUFBSyxHQUFHLElBQUksWUFBWSxFQUFXLENBQUM7UUFFckQ7Ozs7V0FJRztRQUNjLFdBQU0sR0FBRyxJQUFJLFlBQVksRUFBd0IsQ0FBQztRQUVuRTs7OztXQUlHO1FBQ2MsU0FBSSxHQUFHLElBQUksWUFBWSxFQUFzQixDQUFDO1FBRS9EOzs7O1dBSUc7UUFDYyxVQUFLLEdBQUcsSUFBSSxZQUFZLEVBQXVCLENBQUM7UUFFakU7O1dBRUc7UUFDYyxVQUFLLEdBQUcsSUFBSSxZQUFZLEVBQVcsQ0FBQztRQTZCckQ7OztXQUdHO1FBQ0ssc0JBQWlCLEdBQUcsS0FBSyxDQUFDO1FBNkJsQzs7V0FFRztRQUNLLHdCQUFtQixHQUFHLEtBQUssQ0FBQztRQUU1QixPQUFFLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFPbEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7UUFFN0Isa0dBQWtHO1FBQ2xHLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxHQUFLLE1BQWUsQ0FBQztRQUUvQyxJQUFLLGdCQUFnQixFQUFHO1lBQ3ZCLE1BQU0sQ0FBRSxLQUFLLENBQUUsR0FBRyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUUsR0FBRyxDQUFFLENBQUMsR0FBRyxDQUFFLE1BQU0sQ0FBRSxDQUFDO1lBRTlELElBQUssS0FBSyxHQUFHLEVBQUUsRUFBRztnQkFDakIsT0FBTyxDQUFDLElBQUksQ0FBRSw2RUFBNkUsQ0FBRSxDQUFDO2FBQzlGO1NBQ0Q7YUFBTTtZQUNOLE9BQU8sQ0FBQyxJQUFJLENBQUUsMkRBQTJELENBQUUsQ0FBQztTQUM1RTtJQUNGLENBQUM7SUF6SUQ7Ozs7T0FJRztJQUNILElBQW9CLFFBQVEsQ0FBRSxVQUFtQjtRQUNoRCxJQUFJLENBQUMsZ0JBQWdCLENBQUUsVUFBVSxDQUFFLENBQUM7SUFDckMsQ0FBQztJQUVELElBQVcsUUFBUTtRQUNsQixJQUFLLElBQUksQ0FBQyxjQUFjLEVBQUc7WUFDMUIsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQztTQUN0QztRQUVELE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQy9CLENBQUM7SUFtQ0Q7O09BRUc7SUFDSCxJQUFXLGNBQWM7UUFDeEIsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUV6QyxJQUFLLElBQUksQ0FBQyxRQUFRLEVBQUc7WUFDcEIsaUZBQWlGO1lBQ2pGLGdEQUFnRDtZQUNoRCxnRUFBZ0U7WUFDaEUseUVBQXlFO1lBQ3pFLGNBQWMsR0FBSyxJQUFJLENBQUMsUUFBaUIsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFFLElBQUksQ0FBQyxFQUFFLENBQUUsQ0FBQztTQUNwRTtRQUVELElBQUssY0FBYyxFQUFHO1lBQ3JCLE9BQU8sY0FBYyxDQUFDLE1BQU0sQ0FBQztTQUM3QjtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2IsQ0FBQztJQWdETSxLQUFLO1FBQ1gsT0FBTyxJQUFJLENBQUMsRUFBRSxDQUFDO0lBQ2hCLENBQUM7SUFvQkQsNEdBQTRHO0lBQ3JHLFdBQVcsQ0FBRSxPQUFzQjtRQUN6QyxJQUFLLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBRSxPQUFPLEVBQUUsTUFBTSxDQUFFLElBQUksT0FBTyxDQUFDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLEVBQUc7WUFDL0csSUFBSSxDQUFDLFVBQVUsQ0FBRSxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBRSxDQUFDO1NBQzdDO0lBQ0YsQ0FBQztJQUVELDRDQUE0QztJQUNyQyxlQUFlO1FBQ3JCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRCx3Q0FBd0M7SUFDakMsS0FBSyxDQUFDLFdBQVc7UUFDdkIsSUFBSyxJQUFJLENBQUMsUUFBUSxFQUFHO1lBQ3BCLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBRSxDQUFDO1NBQ3RDO2FBQU0sSUFBSyxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFHO1lBQy9ELE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUVwQyxJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztTQUNoQztJQUNGLENBQUM7SUFFRCxrRkFBa0Y7SUFDM0UsVUFBVSxDQUFFLEtBQW9CO1FBQ3RDLG9FQUFvRTtRQUNwRSxtRUFBbUU7UUFDbkUsSUFBSyxLQUFLLEtBQUssSUFBSSxFQUFHO1lBQ3JCLEtBQUssR0FBRyxFQUFFLENBQUM7U0FDWDtRQUVELDBCQUEwQjtRQUMxQixJQUFLLElBQUksQ0FBQyxjQUFjLEVBQUc7WUFDMUIsMkVBQTJFO1lBQzNFLDZCQUE2QjtZQUM3QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDO1lBQ2hDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBRSxLQUFLLENBQUUsQ0FBQztZQUN0QyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1NBQ2pDO1FBQ0QsbURBQW1EO2FBQzlDO1lBQ0osdUVBQXVFO1lBQ3ZFLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1lBRWxCLHNDQUFzQztZQUN0QyxvREFBb0Q7WUFDcEQsSUFBSSxDQUFDLEtBQUs7aUJBQ1IsSUFBSSxDQUFFLEtBQUssRUFBRSxDQUFFO2lCQUNmLFNBQVMsQ0FBRSxNQUFNLENBQUMsRUFBRTtnQkFDcEIsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUUsSUFBSSxDQUFDLElBQUksQ0FBRSxDQUFDO1lBQzlCLENBQUMsQ0FBRSxDQUFDO1NBQ0w7SUFDRixDQUFDO0lBRUQsa0ZBQWtGO0lBQzNFLGdCQUFnQixDQUFFLFFBQWtDO1FBQzFELElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDO0lBQzdCLENBQUM7SUFFRCxrRkFBa0Y7SUFDM0UsaUJBQWlCLENBQUUsUUFBb0I7UUFDN0MsSUFBSSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUM7SUFDOUIsQ0FBQztJQUVELGtGQUFrRjtJQUMzRSxnQkFBZ0IsQ0FBRSxVQUFtQjtRQUMzQywwQkFBMEI7UUFDMUIsSUFBSyxJQUFJLENBQUMsY0FBYyxFQUFHO1lBQzFCLElBQUssVUFBVSxFQUFHO2dCQUNqQixJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFFLHFDQUFxQyxDQUFFLENBQUM7YUFDaEY7aUJBQU07Z0JBQ04sSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBRSxxQ0FBcUMsQ0FBRSxDQUFDO2FBQ2pGO1NBQ0Q7UUFFRCwrREFBK0Q7UUFDL0QsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGdCQUFnQjtRQUN2QixnSEFBZ0g7UUFDaEgsTUFBTSxPQUFPLEdBQUcsQ0FBRSxDQUFFLGFBQTRELEVBQUUsTUFBb0IsRUFBRyxFQUFFO1lBQzFHLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBRSxLQUFLLElBQUksRUFBRTtnQkFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFFLGFBQTRCLENBQUUsQ0FBQztnQkFFMUUsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTyxDQUFDLE1BQU0sQ0FBRSxhQUE0QixFQUFFLE1BQU0sQ0FBRSxDQUFDO2dCQUVqRixJQUFLLElBQUksQ0FBQyxpQkFBaUIsRUFBRztvQkFDN0IsTUFBTSxDQUFDLGtCQUFrQixDQUFFLHFDQUFxQyxDQUFFLENBQUM7aUJBQ25FO2dCQUVELElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFFLEdBQUcsRUFBRTtvQkFDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUUsTUFBTSxDQUFFLENBQUM7Z0JBQzNCLENBQUMsQ0FBRSxDQUFDO2dCQUVKLElBQUksQ0FBQyxpQkFBaUIsQ0FBRSxNQUFNLENBQUUsQ0FBQztnQkFFakMsT0FBTyxNQUFNLENBQUM7WUFDZixDQUFDLENBQUUsQ0FBQztRQUNMLENBQUMsQ0FBRSxDQUFDO1FBRUosTUFBTSxVQUFVLEdBQUcsS0FBSyxFQUFHLE1BQWMsRUFBRyxFQUFFO1lBQzdDLE1BQU0sTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBRXZCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBRSxJQUFJLENBQUMsYUFBYyxDQUFFLENBQUM7UUFDbEUsQ0FBQyxDQUFDO1FBRUYsTUFBTSxTQUFTLEdBQUcsQ0FBRSxDQUFXLEVBQUcsRUFBRTtZQUNuQyw2RUFBNkU7WUFDN0Usd0NBQXdDO1lBQ3hDLHlGQUF5RjtZQUN6RixrREFBa0Q7WUFDbEQsSUFBSyxZQUFZLENBQUUsSUFBSSxDQUFDLEtBQUssQ0FBRSxFQUFHO2dCQUNqQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBRSxDQUFDLENBQUUsQ0FBRSxDQUFDO2FBQzlDO1FBQ0YsQ0FBQyxDQUFDO1FBQ0YsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxJQUFJLENBQUMsT0FBTyxDQUFFLENBQUM7UUFDdkQsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBRWhDLElBQUksQ0FBQyxhQUFhLEdBQUcsT0FBTyxDQUFDO1FBRTdCLDZFQUE2RTtRQUM3RSxJQUFLLElBQUksQ0FBQyxRQUFRLEVBQUc7WUFDcEIsZ0dBQWdHO1lBQ2hHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFFO2dCQUNsQixFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7Z0JBQ1gsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsT0FBTztnQkFDUCxVQUFVO2dCQUNWLG1CQUFtQixFQUFFLE9BQU87Z0JBQzVCLE1BQU07YUFDTixDQUFFLENBQUMsS0FBSyxDQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUNkLFNBQVMsQ0FBRSxDQUFDLENBQUUsQ0FBQztZQUNoQixDQUFDLENBQUUsQ0FBQztZQUVKLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFFLFdBQVcsRUFBRSxDQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFHLEVBQUU7Z0JBQ2xELElBQUssTUFBTSxLQUFLLElBQUksQ0FBQyxFQUFFLEVBQUc7b0JBQ3pCLFNBQVMsRUFBRSxDQUFDO2lCQUNaO1lBQ0YsQ0FBQyxDQUFFLENBQUM7U0FDSjthQUFNO1lBQ04sNEVBQTRFO1lBQzVFLE1BQU0sY0FBYyxHQUFHLElBQUksY0FBYyxDQUN4QyxJQUFJLENBQUMsTUFBTyxFQUNaLElBQUksQ0FBQyxvQkFBb0IsQ0FBRSxDQUFDO1lBRTdCLGNBQWMsQ0FBQyxVQUFVLENBQUUsT0FBTyxDQUFFLENBQUM7WUFDckMsY0FBYyxDQUFDLGFBQWEsQ0FBRSxVQUFVLENBQUUsQ0FBQztZQUMzQyxjQUFjLENBQUMsRUFBRSxDQUFFLE9BQU8sRUFBRSxTQUFTLENBQUUsQ0FBQztZQUV4QyxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztZQUNyQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFFLEdBQUcsRUFBRTtnQkFDbkMsbUZBQW1GO2dCQUNuRix5RkFBeUY7Z0JBQ3pGLGNBQWMsQ0FBQyxNQUFNLENBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBRSxDQUFDLEtBQUssQ0FBRSxDQUFDLENBQUMsRUFBRTtvQkFDbkQsU0FBUyxDQUFFLENBQUMsQ0FBRSxDQUFDO2dCQUNoQixDQUFDLENBQUUsQ0FBQztZQUNMLENBQUMsQ0FBRSxDQUFDO1NBQ0o7SUFDRixDQUFDO0lBRU8sU0FBUztRQUNoQixJQUFLLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUc7WUFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBRSx3RkFBd0YsQ0FBRSxDQUFDO1NBQzVHO1FBRUQsTUFBTSxNQUFNLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVsQyxpRkFBaUY7UUFDakYsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQztRQUV6RCxJQUFLLFdBQVcsRUFBRztZQUNsQiw4RUFBOEU7WUFDOUUsTUFBTSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7U0FDakM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNmLENBQUM7SUFFRDs7T0FFRztJQUNLLGlCQUFpQixDQUFFLE1BQWU7UUFDekMsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFDNUMsTUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBRWxELGFBQWEsQ0FBQyxFQUFFLENBQXVCLGFBQWEsRUFBRSxHQUFHLENBQUMsRUFBRTtZQUMzRCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBRSxHQUFHLEVBQUU7Z0JBQ3JCLElBQUssSUFBSSxDQUFDLHdCQUF3QixFQUFHO29CQUNwQyxPQUFPO2lCQUNQO2dCQUVELElBQUssSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRztvQkFDcEQsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFFL0IsSUFBSSxDQUFDLFdBQVcsQ0FBRSxJQUFJLENBQUUsQ0FBQztpQkFDekI7Z0JBRUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxDQUFFLENBQUM7WUFDNUMsQ0FBQyxDQUFFLENBQUM7UUFDTCxDQUFDLENBQUUsQ0FBQztRQUVKLFlBQVksQ0FBQyxFQUFFLENBQTBCLE9BQU8sRUFBRSxHQUFHLENBQUMsRUFBRTtZQUN2RCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBRSxHQUFHLEVBQUU7Z0JBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsQ0FBRSxDQUFDO1lBQzNDLENBQUMsQ0FBRSxDQUFDO1FBQ0wsQ0FBQyxDQUFFLENBQUM7UUFFSixZQUFZLENBQUMsRUFBRSxDQUF5QixNQUFNLEVBQUUsR0FBRyxDQUFDLEVBQUU7WUFDckQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUUsR0FBRyxFQUFFO2dCQUNyQixJQUFLLElBQUksQ0FBQyxZQUFZLEVBQUc7b0JBQ3hCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztpQkFDcEI7Z0JBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxDQUFFLENBQUM7WUFDMUMsQ0FBQyxDQUFFLENBQUM7UUFDTCxDQUFDLENBQUUsQ0FBQztJQUNMLENBQUM7OzhHQS9aVyxpQkFBaUI7a0dBQWpCLGlCQUFpQixrV0FUbEI7UUFDVjtZQUNDLE9BQU8sRUFBRSxpQkFBaUI7WUFDMUIsbUVBQW1FO1lBQ25FLFdBQVcsRUFBRSxVQUFVLENBQUUsR0FBRyxFQUFFLENBQUMsaUJBQWlCLENBQUU7WUFDbEQsS0FBSyxFQUFFLElBQUk7U0FDWDtLQUNELCtDQVZTLDZCQUE2QjsyRkFZM0IsaUJBQWlCO2tCQWQ3QixTQUFTO21CQUFFO29CQUNYLFFBQVEsRUFBRSxVQUFVO29CQUNwQixRQUFRLEVBQUUsNkJBQTZCO29CQUV2QyxtQ0FBbUM7b0JBQ25DLFNBQVMsRUFBRTt3QkFDVjs0QkFDQyxPQUFPLEVBQUUsaUJBQWlCOzRCQUMxQixtRUFBbUU7NEJBQ25FLFdBQVcsRUFBRSxVQUFVLENBQUUsR0FBRyxFQUFFLGtCQUFrQixDQUFFOzRCQUNsRCxLQUFLLEVBQUUsSUFBSTt5QkFDWDtxQkFDRDtpQkFDRDtzSEFXZ0IsTUFBTTtzQkFBckIsS0FBSztnQkFPVSxNQUFNO3NCQUFyQixLQUFLO2dCQU1VLElBQUk7c0JBQW5CLEtBQUs7Z0JBT1UsT0FBTztzQkFBdEIsS0FBSztnQkFNVSxRQUFRO3NCQUF2QixLQUFLO2dCQUtVLG9CQUFvQjtzQkFBbkMsS0FBSztnQkFXVSx3QkFBd0I7c0JBQXZDLEtBQUs7Z0JBT2MsUUFBUTtzQkFBM0IsS0FBSztnQkFpQlcsS0FBSztzQkFBckIsTUFBTTtnQkFPVSxNQUFNO3NCQUF0QixNQUFNO2dCQU9VLElBQUk7c0JBQXBCLE1BQU07Z0JBT1UsS0FBSztzQkFBckIsTUFBTTtnQkFLVSxLQUFLO3NCQUFyQixNQUFNOztBQTRUUixTQUFTLFlBQVksQ0FBSyxPQUF3QjtJQUNqRCwyRUFBMkU7SUFDM0UseUVBQXlFO0lBQ3pFLE9BQVMsT0FBZ0IsQ0FBQyxRQUFRLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQ3BFLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlIENvcHlyaWdodCAoYykgMjAwMy0yMDIzLCBDS1NvdXJjZSBIb2xkaW5nIHNwLiB6IG8uby4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbiAqIEZvciBsaWNlbnNpbmcsIHNlZSBMSUNFTlNFLm1kLlxuICovXG5cbmltcG9ydCB0eXBlIHtcblx0QWZ0ZXJWaWV3SW5pdCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3ksIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7XG5cdENvbXBvbmVudCxcblx0SW5wdXQsXG5cdE91dHB1dCxcblx0Tmdab25lLFxuXHRFdmVudEVtaXR0ZXIsXG5cdGZvcndhcmRSZWYsXG5cdEVsZW1lbnRSZWZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENvbnRleHRXYXRjaGRvZywgRWRpdG9yV2F0Y2hkb2cgfSBmcm9tICdAY2tlZGl0b3IvY2tlZGl0b3I1LXdhdGNoZG9nJztcbmltcG9ydCB7IFdhdGNoZG9nQ29uZmlnIH0gZnJvbSAnQGNrZWRpdG9yL2NrZWRpdG9yNS13YXRjaGRvZy9zcmMvd2F0Y2hkb2cnO1xuaW1wb3J0IHsgdHlwZSBFZGl0b3IsIEVkaXRvckNvbmZpZyB9IGZyb20gJ0Bja2VkaXRvci9ja2VkaXRvcjUtY29yZSc7XG5pbXBvcnQgdHlwZSB7IEdldEV2ZW50SW5mbyB9IGZyb20gJ0Bja2VkaXRvci9ja2VkaXRvcjUtdXRpbHMnO1xuaW1wb3J0IHR5cGUgeyBEb2N1bWVudENoYW5nZUV2ZW50IH0gZnJvbSAnQGNrZWRpdG9yL2NrZWRpdG9yNS1lbmdpbmUnO1xuaW1wb3J0IHR5cGUgeyBWaWV3RG9jdW1lbnRCbHVyRXZlbnQsIFZpZXdEb2N1bWVudEZvY3VzRXZlbnQgfSBmcm9tICdAY2tlZGl0b3IvY2tlZGl0b3I1LWVuZ2luZS9zcmMvdmlldy9vYnNlcnZlci9mb2N1c29ic2VydmVyJztcbmltcG9ydCB7IGZpcnN0IH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuXG5pbXBvcnQgdWlkIGZyb20gJy4vdWlkJztcblxuaW1wb3J0IHR5cGUge1xuXHRDb250cm9sVmFsdWVBY2Nlc3NvciB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7XG5cdE5HX1ZBTFVFX0FDQ0VTU09SXG59IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcblxuY29uc3QgQU5HVUxBUl9JTlRFR1JBVElPTl9SRUFEX09OTFlfTE9DS19JRCA9ICdMb2NrIGZyb20gQW5ndWxhciBpbnRlZ3JhdGlvbiAoQGNrZWRpdG9yL2NrZWRpdG9yNS1hbmd1bGFyKSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQmx1ckV2ZW50PFRFZGl0b3IgZXh0ZW5kcyBFZGl0b3IgPSBFZGl0b3I+IHtcblx0ZXZlbnQ6IEdldEV2ZW50SW5mbzxWaWV3RG9jdW1lbnRCbHVyRXZlbnQ+O1xuXHRlZGl0b3I6IFRFZGl0b3I7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRm9jdXNFdmVudDxURWRpdG9yIGV4dGVuZHMgRWRpdG9yID0gRWRpdG9yPiB7XG5cdGV2ZW50OiBHZXRFdmVudEluZm88Vmlld0RvY3VtZW50Rm9jdXNFdmVudD47XG5cdGVkaXRvcjogVEVkaXRvcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDaGFuZ2VFdmVudDxURWRpdG9yIGV4dGVuZHMgRWRpdG9yID0gRWRpdG9yPiB7XG5cdGV2ZW50OiBHZXRFdmVudEluZm88RG9jdW1lbnRDaGFuZ2VFdmVudD47XG5cdGVkaXRvcjogVEVkaXRvcjtcbn1cblxuQENvbXBvbmVudCgge1xuXHRzZWxlY3RvcjogJ2NrZWRpdG9yJyxcblx0dGVtcGxhdGU6ICc8bmctdGVtcGxhdGU+PC9uZy10ZW1wbGF0ZT4nLFxuXG5cdC8vIEludGVncmF0aW9uIHdpdGggQGFuZ3VsYXIvZm9ybXMuXG5cdHByb3ZpZGVyczogW1xuXHRcdHtcblx0XHRcdHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuXHRcdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11c2UtYmVmb3JlLWRlZmluZVxuXHRcdFx0dXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoICgpID0+IENLRWRpdG9yQ29tcG9uZW50ICksXG5cdFx0XHRtdWx0aTogdHJ1ZVxuXHRcdH1cblx0XVxufSApXG5leHBvcnQgY2xhc3MgQ0tFZGl0b3JDb21wb25lbnQ8VEVkaXRvciBleHRlbmRzIEVkaXRvciA9IEVkaXRvcj4gaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3ksIE9uQ2hhbmdlcywgQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuXHQvKipcblx0ICogVGhlIHJlZmVyZW5jZSB0byB0aGUgRE9NIGVsZW1lbnQgY3JlYXRlZCBieSB0aGUgY29tcG9uZW50LlxuXHQgKi9cblx0cHJpdmF0ZSBlbGVtZW50UmVmITogRWxlbWVudFJlZjxIVE1MRWxlbWVudD47XG5cblx0LyoqXG5cdCAqIFRoZSBjb25zdHJ1Y3RvciBvZiB0aGUgZWRpdG9yIHRvIGJlIHVzZWQgZm9yIHRoZSBpbnN0YW5jZSBvZiB0aGUgY29tcG9uZW50LlxuXHQgKiBJdCBjYW4gYmUgZS5nLiB0aGUgYENsYXNzaWNFZGl0b3JCdWlsZGAsIGBJbmxpbmVFZGl0b3JCdWlsZGAgb3Igc29tZSBjdXN0b20gZWRpdG9yLlxuXHQgKi9cblx0QElucHV0KCkgcHVibGljIGVkaXRvcj86IHsgY3JlYXRlKCBzb3VyY2VFbGVtZW50T3JEYXRhOiBIVE1MRWxlbWVudCB8IHN0cmluZywgY29uZmlnPzogRWRpdG9yQ29uZmlnICk6IFByb21pc2U8VEVkaXRvcj4gfTtcblxuXHQvKipcblx0ICogVGhlIGNvbmZpZ3VyYXRpb24gb2YgdGhlIGVkaXRvci5cblx0ICogU2VlIGh0dHBzOi8vY2tlZGl0b3IuY29tL2RvY3MvY2tlZGl0b3I1L2xhdGVzdC9hcGkvbW9kdWxlX2NvcmVfZWRpdG9yX2VkaXRvcmNvbmZpZy1FZGl0b3JDb25maWcuaHRtbFxuXHQgKiB0byBsZWFybiBtb3JlLlxuXHQgKi9cblx0QElucHV0KCkgcHVibGljIGNvbmZpZzogRWRpdG9yQ29uZmlnID0ge307XG5cblx0LyoqXG5cdCAqIFRoZSBpbml0aWFsIGRhdGEgb2YgdGhlIGVkaXRvci4gVXNlZnVsIHdoZW4gbm90IHVzaW5nIHRoZSBuZ01vZGVsLlxuXHQgKiBTZWUgaHR0cHM6Ly9hbmd1bGFyLmlvL2FwaS9mb3Jtcy9OZ01vZGVsIHRvIGxlYXJuIG1vcmUuXG5cdCAqL1xuXHRASW5wdXQoKSBwdWJsaWMgZGF0YSA9ICcnO1xuXG5cdC8qKlxuXHQgKiBUYWcgbmFtZSBvZiB0aGUgZWRpdG9yIGNvbXBvbmVudC5cblx0ICpcblx0ICogVGhlIGRlZmF1bHQgdGFnIGlzICdkaXYnLlxuXHQgKi9cblx0QElucHV0KCkgcHVibGljIHRhZ05hbWUgPSAnZGl2JztcblxuXHQvLyBUT0RPIENoYW5nZSB0byBDb250ZXh0V2F0Y2hkb2c8RWRpdG9yLCBIVE1MRWxlbWVudD4gYWZ0ZXIgbmV3IGNrZWRpdG9yNSBhbHBoYSByZWxlYXNlXG5cdC8qKlxuXHQgKiBUaGUgY29udGV4dCB3YXRjaGRvZy5cblx0ICovXG5cdEBJbnB1dCgpIHB1YmxpYyB3YXRjaGRvZz86IENvbnRleHRXYXRjaGRvZztcblxuXHQvKipcblx0ICogQ29uZmlnIGZvciB0aGUgRWRpdG9yV2F0Y2hkb2cuXG5cdCAqL1xuXHRASW5wdXQoKSBwdWJsaWMgZWRpdG9yV2F0Y2hkb2dDb25maWc/OiBXYXRjaGRvZ0NvbmZpZztcblxuXHQvKipcblx0ICogQWxsb3dzIGRpc2FibGluZyB0aGUgdHdvLXdheSBkYXRhIGJpbmRpbmcgbWVjaGFuaXNtLiBEaXNhYmxpbmcgaXQgY2FuIGJvb3N0IHBlcmZvcm1hbmNlIGZvciBsYXJnZSBkb2N1bWVudHMuXG5cdCAqXG5cdCAqIFdoZW4gYSBjb21wb25lbnQgaXMgY29ubmVjdGVkIHVzaW5nIHRoZSBbKG5nTW9kZWwpXSBvciBbZm9ybUNvbnRyb2xdIGRpcmVjdGl2ZXMgYW5kIHRoaXMgdmFsdWUgaXMgc2V0IHRvIHRydWUgdGhlbiBub25lIG9mIHRoZSBkYXRhXG5cdCAqIHdpbGwgZXZlciBiZSBzeW5jaHJvbml6ZWQuXG5cdCAqXG5cdCAqIEFuIGludGVncmF0b3IgbXVzdCBjYWxsIGBlZGl0b3IuZGF0YS5nZXQoKWAgbWFudWFsbHkgb25jZSB0aGUgYXBwbGljYXRpb24gbmVlZHMgdGhlIGVkaXRvcidzIGRhdGEuXG5cdCAqIEFuIGVkaXRvciBpbnN0YW5jZSBjYW4gYmUgcmVjZWl2ZWQgaW4gdGhlIGByZWFkeSgpYCBjYWxsYmFjay5cblx0ICovXG5cdEBJbnB1dCgpIHB1YmxpYyBkaXNhYmxlVHdvV2F5RGF0YUJpbmRpbmcgPSBmYWxzZTtcblxuXHQvKipcblx0ICogV2hlbiBzZXQgYHRydWVgLCB0aGUgZWRpdG9yIGJlY29tZXMgcmVhZC1vbmx5LlxuXHQgKiBTZWUgaHR0cHM6Ly9ja2VkaXRvci5jb20vZG9jcy9ja2VkaXRvcjUvbGF0ZXN0L2FwaS9tb2R1bGVfY29yZV9lZGl0b3JfZWRpdG9yLUVkaXRvci5odG1sI21lbWJlci1pc1JlYWRPbmx5XG5cdCAqIHRvIGxlYXJuIG1vcmUuXG5cdCAqL1xuXHRASW5wdXQoKSBwdWJsaWMgc2V0IGRpc2FibGVkKCBpc0Rpc2FibGVkOiBib29sZWFuICkge1xuXHRcdHRoaXMuc2V0RGlzYWJsZWRTdGF0ZSggaXNEaXNhYmxlZCApO1xuXHR9XG5cblx0cHVibGljIGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcblx0XHRpZiAoIHRoaXMuZWRpdG9ySW5zdGFuY2UgKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5lZGl0b3JJbnN0YW5jZS5pc1JlYWRPbmx5O1xuXHRcdH1cblxuXHRcdHJldHVybiB0aGlzLmluaXRpYWxseURpc2FibGVkO1xuXHR9XG5cblx0LyoqXG5cdCAqIEZpcmVzIHdoZW4gdGhlIGVkaXRvciBpcyByZWFkeS4gSXQgY29ycmVzcG9uZHMgd2l0aCB0aGUgYGVkaXRvciNyZWFkeWBcblx0ICogaHR0cHM6Ly9ja2VkaXRvci5jb20vZG9jcy9ja2VkaXRvcjUvbGF0ZXN0L2FwaS9tb2R1bGVfY29yZV9lZGl0b3JfZWRpdG9yLUVkaXRvci5odG1sI2V2ZW50LXJlYWR5XG5cdCAqIGV2ZW50LlxuXHQgKi9cblx0QE91dHB1dCgpIHB1YmxpYyByZWFkeSA9IG5ldyBFdmVudEVtaXR0ZXI8VEVkaXRvcj4oKTtcblxuXHQvKipcblx0ICogRmlyZXMgd2hlbiB0aGUgY29udGVudCBvZiB0aGUgZWRpdG9yIGhhcyBjaGFuZ2VkLiBJdCBjb3JyZXNwb25kcyB3aXRoIHRoZSBgZWRpdG9yLm1vZGVsLmRvY3VtZW50I2NoYW5nZWBcblx0ICogaHR0cHM6Ly9ja2VkaXRvci5jb20vZG9jcy9ja2VkaXRvcjUvbGF0ZXN0L2FwaS9tb2R1bGVfZW5naW5lX21vZGVsX2RvY3VtZW50LURvY3VtZW50Lmh0bWwjZXZlbnQtY2hhbmdlXG5cdCAqIGV2ZW50LlxuXHQgKi9cblx0QE91dHB1dCgpIHB1YmxpYyBjaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPENoYW5nZUV2ZW50PFRFZGl0b3I+PigpO1xuXG5cdC8qKlxuXHQgKiBGaXJlcyB3aGVuIHRoZSBlZGl0aW5nIHZpZXcgb2YgdGhlIGVkaXRvciBpcyBibHVycmVkLiBJdCBjb3JyZXNwb25kcyB3aXRoIHRoZSBgZWRpdG9yLmVkaXRpbmcudmlldy5kb2N1bWVudCNibHVyYFxuXHQgKiBodHRwczovL2NrZWRpdG9yLmNvbS9kb2NzL2NrZWRpdG9yNS9sYXRlc3QvYXBpL21vZHVsZV9lbmdpbmVfdmlld19kb2N1bWVudC1Eb2N1bWVudC5odG1sI2V2ZW50LWV2ZW50OmJsdXJcblx0ICogZXZlbnQuXG5cdCAqL1xuXHRAT3V0cHV0KCkgcHVibGljIGJsdXIgPSBuZXcgRXZlbnRFbWl0dGVyPEJsdXJFdmVudDxURWRpdG9yPj4oKTtcblxuXHQvKipcblx0ICogRmlyZXMgd2hlbiB0aGUgZWRpdGluZyB2aWV3IG9mIHRoZSBlZGl0b3IgaXMgZm9jdXNlZC4gSXQgY29ycmVzcG9uZHMgd2l0aCB0aGUgYGVkaXRvci5lZGl0aW5nLnZpZXcuZG9jdW1lbnQjZm9jdXNgXG5cdCAqIGh0dHBzOi8vY2tlZGl0b3IuY29tL2RvY3MvY2tlZGl0b3I1L2xhdGVzdC9hcGkvbW9kdWxlX2VuZ2luZV92aWV3X2RvY3VtZW50LURvY3VtZW50Lmh0bWwjZXZlbnQtZXZlbnQ6Zm9jdXNcblx0ICogZXZlbnQuXG5cdCAqL1xuXHRAT3V0cHV0KCkgcHVibGljIGZvY3VzID0gbmV3IEV2ZW50RW1pdHRlcjxGb2N1c0V2ZW50PFRFZGl0b3I+PigpO1xuXG5cdC8qKlxuXHQgKiBGaXJlcyB3aGVuIHRoZSBlZGl0b3IgY29tcG9uZW50IGNyYXNoZXMuXG5cdCAqL1xuXHRAT3V0cHV0KCkgcHVibGljIGVycm9yID0gbmV3IEV2ZW50RW1pdHRlcjx1bmtub3duPigpO1xuXG5cdC8qKlxuXHQgKiBUaGUgaW5zdGFuY2Ugb2YgdGhlIGVkaXRvciBjcmVhdGVkIGJ5IHRoaXMgY29tcG9uZW50LlxuXHQgKi9cblx0cHVibGljIGdldCBlZGl0b3JJbnN0YW5jZSgpOiBURWRpdG9yIHwgbnVsbCB7XG5cdFx0bGV0IGVkaXRvcldhdGNoZG9nID0gdGhpcy5lZGl0b3JXYXRjaGRvZztcblxuXHRcdGlmICggdGhpcy53YXRjaGRvZyApIHtcblx0XHRcdC8vIFRlbXBvcmFyaWx5IHVzZSB0aGUgYF93YXRjaGRvZ3NgIGludGVybmFsIG1hcCBhcyB0aGUgYGdldEl0ZW0oKWAgbWV0aG9kIHRocm93c1xuXHRcdFx0Ly8gYW4gZXJyb3Igd2hlbiB0aGUgaXRlbSBpcyBub3QgcmVnaXN0ZXJlZCB5ZXQuXG5cdFx0XHQvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2NrZWRpdG9yL2NrZWRpdG9yNS1hbmd1bGFyL2lzc3Vlcy8xNzcuXG5cdFx0XHQvLyBUT0RPIHNob3VsZCBiZSBhYmxlIHRvIGNoYW5nZSB3aGVuIG5ldyBjaGFnZXMgaW4gV2F0Y2RvZyBhcmUgcmVsZWFzZWQuXG5cdFx0XHRlZGl0b3JXYXRjaGRvZyA9ICggdGhpcy53YXRjaGRvZyBhcyBhbnkgKS5fd2F0Y2hkb2dzLmdldCggdGhpcy5pZCApO1xuXHRcdH1cblxuXHRcdGlmICggZWRpdG9yV2F0Y2hkb2cgKSB7XG5cdFx0XHRyZXR1cm4gZWRpdG9yV2F0Y2hkb2cuZWRpdG9yO1xuXHRcdH1cblxuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cblx0LyoqXG5cdCAqIFRoZSBlZGl0b3Igd2F0Y2hkb2cuIEl0IGlzIGNyZWF0ZWQgd2hlbiB0aGUgY29udGV4dCB3YXRjaGRvZyBpcyBub3QgcGFzc2VkIHRvIHRoZSBjb21wb25lbnQuXG5cdCAqIEl0IGtlZXBzIHRoZSBlZGl0b3IgcnVubmluZy5cblx0ICovXG5cdHByaXZhdGUgZWRpdG9yV2F0Y2hkb2c/OiBFZGl0b3JXYXRjaGRvZzxURWRpdG9yPjtcblxuXHQvKipcblx0ICogSWYgdGhlIGNvbXBvbmVudCBpcyByZWFk4oCTb25seSBiZWZvcmUgdGhlIGVkaXRvciBpbnN0YW5jZSBpcyBjcmVhdGVkLCBpdCByZW1lbWJlcnMgdGhhdCBzdGF0ZSxcblx0ICogc28gdGhlIGVkaXRvciBjYW4gYmVjb21lIHJlYWTigJNvbmx5IG9uY2UgaXQgaXMgcmVhZHkuXG5cdCAqL1xuXHRwcml2YXRlIGluaXRpYWxseURpc2FibGVkID0gZmFsc2U7XG5cblx0LyoqXG5cdCAqIEFuIGluc3RhbmNlIG9mIGh0dHBzOi8vYW5ndWxhci5pby9hcGkvY29yZS9OZ1pvbmUgdG8gYWxsb3cgdGhlIGludGVyYWN0aW9uIHdpdGggdGhlIGVkaXRvclxuXHQgKiB3aXRoaW5nIHRoZSBBbmd1bGFyIGV2ZW50IGxvb3AuXG5cdCAqL1xuXHRwcml2YXRlIG5nWm9uZTogTmdab25lO1xuXG5cdC8qKlxuXHQgKiBBIGNhbGxiYWNrIGV4ZWN1dGVkIHdoZW4gdGhlIGNvbnRlbnQgb2YgdGhlIGVkaXRvciBjaGFuZ2VzLiBQYXJ0IG9mIHRoZVxuXHQgKiBgQ29udHJvbFZhbHVlQWNjZXNzb3JgIChodHRwczovL2FuZ3VsYXIuaW8vYXBpL2Zvcm1zL0NvbnRyb2xWYWx1ZUFjY2Vzc29yKSBpbnRlcmZhY2UuXG5cdCAqXG5cdCAqIE5vdGU6IFVuc2V0IHVubGVzcyB0aGUgY29tcG9uZW50IHVzZXMgdGhlIGBuZ01vZGVsYC5cblx0ICovXG5cdHByaXZhdGUgY3ZhT25DaGFuZ2U/OiAoIGRhdGE6IHN0cmluZyApID0+IHZvaWQ7XG5cblx0LyoqXG5cdCAqIEEgY2FsbGJhY2sgZXhlY3V0ZWQgd2hlbiB0aGUgZWRpdG9yIGhhcyBiZWVuIGJsdXJyZWQuIFBhcnQgb2YgdGhlXG5cdCAqIGBDb250cm9sVmFsdWVBY2Nlc3NvcmAgKGh0dHBzOi8vYW5ndWxhci5pby9hcGkvZm9ybXMvQ29udHJvbFZhbHVlQWNjZXNzb3IpIGludGVyZmFjZS5cblx0ICpcblx0ICogTm90ZTogVW5zZXQgdW5sZXNzIHRoZSBjb21wb25lbnQgdXNlcyB0aGUgYG5nTW9kZWxgLlxuXHQgKi9cblx0cHJpdmF0ZSBjdmFPblRvdWNoZWQ/OiAoKSA9PiB2b2lkO1xuXG5cdC8qKlxuXHQgKiBSZWZlcmVuY2UgdG8gdGhlIHNvdXJjZSBlbGVtZW50IHVzZWQgYnkgdGhlIGVkaXRvci5cblx0ICovXG5cdHByaXZhdGUgZWRpdG9yRWxlbWVudD86IEhUTUxFbGVtZW50O1xuXG5cdC8qKlxuXHQgKiBBIGxvY2sgZmxhZyBwcmV2ZW50aW5nIGZyb20gY2FsbGluZyB0aGUgYGN2YU9uQ2hhbmdlKClgIGR1cmluZyBzZXR0aW5nIGVkaXRvciBkYXRhLlxuXHQgKi9cblx0cHJpdmF0ZSBpc0VkaXRvclNldHRpbmdEYXRhID0gZmFsc2U7XG5cblx0cHJpdmF0ZSBpZCA9IHVpZCgpO1xuXG5cdHB1YmxpYyBnZXRJZCgpOiBzdHJpbmcge1xuXHRcdHJldHVybiB0aGlzLmlkO1xuXHR9XG5cblx0cHVibGljIGNvbnN0cnVjdG9yKCBlbGVtZW50UmVmOiBFbGVtZW50UmVmLCBuZ1pvbmU6IE5nWm9uZSApIHtcblx0XHR0aGlzLm5nWm9uZSA9IG5nWm9uZTtcblx0XHR0aGlzLmVsZW1lbnRSZWYgPSBlbGVtZW50UmVmO1xuXG5cdFx0Ly8gVG8gYXZvaWQgaXNzdWVzIHdpdGggdGhlIGNvbW11bml0eSB0eXBpbmdzIGFuZCBDS0VkaXRvciA1LCBsZXQncyB0cmVhdCB3aW5kb3cgYXMgYW55LiBTZWUgIzM0Mi5cblx0XHRjb25zdCB7IENLRURJVE9SX1ZFUlNJT04gfSA9ICggd2luZG93IGFzIGFueSApO1xuXG5cdFx0aWYgKCBDS0VESVRPUl9WRVJTSU9OICkge1xuXHRcdFx0Y29uc3QgWyBtYWpvciBdID0gQ0tFRElUT1JfVkVSU0lPTi5zcGxpdCggJy4nICkubWFwKCBOdW1iZXIgKTtcblxuXHRcdFx0aWYgKCBtYWpvciA8IDM3ICkge1xuXHRcdFx0XHRjb25zb2xlLndhcm4oICdUaGUgPENLRWRpdG9yPiBjb21wb25lbnQgcmVxdWlyZXMgdXNpbmcgQ0tFZGl0b3IgNSBpbiB2ZXJzaW9uIDM3IG9yIGhpZ2hlci4nICk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnNvbGUud2FybiggJ0Nhbm5vdCBmaW5kIHRoZSBcIkNLRURJVE9SX1ZFUlNJT05cIiBpbiB0aGUgXCJ3aW5kb3dcIiBzY29wZS4nICk7XG5cdFx0fVxuXHR9XG5cblx0Ly8gSW1wbGVtZW50aW5nIHRoZSBPbkNoYW5nZXMgaW50ZXJmYWNlLiBXaGVuZXZlciB0aGUgYGRhdGFgIHByb3BlcnR5IGlzIGNoYW5nZWQsIHVwZGF0ZSB0aGUgZWRpdG9yIGNvbnRlbnQuXG5cdHB1YmxpYyBuZ09uQ2hhbmdlcyggY2hhbmdlczogU2ltcGxlQ2hhbmdlcyApOiB2b2lkIHtcblx0XHRpZiAoIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCggY2hhbmdlcywgJ2RhdGEnICkgJiYgY2hhbmdlcy5kYXRhICYmICFjaGFuZ2VzLmRhdGEuaXNGaXJzdENoYW5nZSgpICkge1xuXHRcdFx0dGhpcy53cml0ZVZhbHVlKCBjaGFuZ2VzLmRhdGEuY3VycmVudFZhbHVlICk7XG5cdFx0fVxuXHR9XG5cblx0Ly8gSW1wbGVtZW50aW5nIHRoZSBBZnRlclZpZXdJbml0IGludGVyZmFjZS5cblx0cHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcblx0XHR0aGlzLmF0dGFjaFRvV2F0Y2hkb2coKTtcblx0fVxuXG5cdC8vIEltcGxlbWVudGluZyB0aGUgT25EZXN0cm95IGludGVyZmFjZS5cblx0cHVibGljIGFzeW5jIG5nT25EZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdGlmICggdGhpcy53YXRjaGRvZyApIHtcblx0XHRcdGF3YWl0IHRoaXMud2F0Y2hkb2cucmVtb3ZlKCB0aGlzLmlkICk7XG5cdFx0fSBlbHNlIGlmICggdGhpcy5lZGl0b3JXYXRjaGRvZyAmJiB0aGlzLmVkaXRvcldhdGNoZG9nLmVkaXRvciApIHtcblx0XHRcdGF3YWl0IHRoaXMuZWRpdG9yV2F0Y2hkb2cuZGVzdHJveSgpO1xuXG5cdFx0XHR0aGlzLmVkaXRvcldhdGNoZG9nID0gdW5kZWZpbmVkO1xuXHRcdH1cblx0fVxuXG5cdC8vIEltcGxlbWVudGluZyB0aGUgQ29udHJvbFZhbHVlQWNjZXNzb3IgaW50ZXJmYWNlIChvbmx5IHdoZW4gYmluZGluZyB0byBuZ01vZGVsKS5cblx0cHVibGljIHdyaXRlVmFsdWUoIHZhbHVlOiBzdHJpbmcgfCBudWxsICk6IHZvaWQge1xuXHRcdC8vIFRoaXMgbWV0aG9kIGlzIGNhbGxlZCB3aXRoIHRoZSBgbnVsbGAgdmFsdWUgd2hlbiB0aGUgZm9ybSByZXNldHMuXG5cdFx0Ly8gQSBjb21wb25lbnQncyByZXNwb25zaWJpbGl0eSBpcyB0byByZXN0b3JlIHRvIHRoZSBpbml0aWFsIHN0YXRlLlxuXHRcdGlmICggdmFsdWUgPT09IG51bGwgKSB7XG5cdFx0XHR2YWx1ZSA9ICcnO1xuXHRcdH1cblxuXHRcdC8vIElmIGFscmVhZHkgaW5pdGlhbGl6ZWQuXG5cdFx0aWYgKCB0aGlzLmVkaXRvckluc3RhbmNlICkge1xuXHRcdFx0Ly8gVGhlIGxvY2sgbWVjaGFuaXNtIHByZXZlbnRzIGZyb20gY2FsbGluZyBgY3ZhT25DaGFuZ2UoKWAgZHVyaW5nIGNoYW5naW5nXG5cdFx0XHQvLyB0aGUgZWRpdG9yIHN0YXRlLiBTZWUgIzEzOVxuXHRcdFx0dGhpcy5pc0VkaXRvclNldHRpbmdEYXRhID0gdHJ1ZTtcblx0XHRcdHRoaXMuZWRpdG9ySW5zdGFuY2UuZGF0YS5zZXQoIHZhbHVlICk7XG5cdFx0XHR0aGlzLmlzRWRpdG9yU2V0dGluZ0RhdGEgPSBmYWxzZTtcblx0XHR9XG5cdFx0Ly8gSWYgbm90LCB3YWl0IGZvciBpdCB0byBiZSByZWFkeTsgc3RvcmUgdGhlIGRhdGEuXG5cdFx0ZWxzZSB7XG5cdFx0XHQvLyBJZiB0aGUgZWRpdG9yIGVsZW1lbnQgaXMgYWxyZWFkeSBhdmFpbGFibGUsIHRoZW4gdXBkYXRlIGl0cyBjb250ZW50LlxuXHRcdFx0dGhpcy5kYXRhID0gdmFsdWU7XG5cblx0XHRcdC8vIElmIG5vdCwgdGhlbiB3YWl0IHVudGlsIGl0IGlzIHJlYWR5XG5cdFx0XHQvLyBhbmQgY2hhbmdlIGRhdGEgb25seSBmb3IgdGhlIGZpcnN0IGByZWFkeWAgZXZlbnQuXG5cdFx0XHR0aGlzLnJlYWR5XG5cdFx0XHRcdC5waXBlKCBmaXJzdCgpIClcblx0XHRcdFx0LnN1YnNjcmliZSggZWRpdG9yID0+IHtcblx0XHRcdFx0XHRlZGl0b3IuZGF0YS5zZXQoIHRoaXMuZGF0YSApO1xuXHRcdFx0XHR9ICk7XG5cdFx0fVxuXHR9XG5cblx0Ly8gSW1wbGVtZW50aW5nIHRoZSBDb250cm9sVmFsdWVBY2Nlc3NvciBpbnRlcmZhY2UgKG9ubHkgd2hlbiBiaW5kaW5nIHRvIG5nTW9kZWwpLlxuXHRwdWJsaWMgcmVnaXN0ZXJPbkNoYW5nZSggY2FsbGJhY2s6ICggZGF0YTogc3RyaW5nICkgPT4gdm9pZCApOiB2b2lkIHtcblx0XHR0aGlzLmN2YU9uQ2hhbmdlID0gY2FsbGJhY2s7XG5cdH1cblxuXHQvLyBJbXBsZW1lbnRpbmcgdGhlIENvbnRyb2xWYWx1ZUFjY2Vzc29yIGludGVyZmFjZSAob25seSB3aGVuIGJpbmRpbmcgdG8gbmdNb2RlbCkuXG5cdHB1YmxpYyByZWdpc3Rlck9uVG91Y2hlZCggY2FsbGJhY2s6ICgpID0+IHZvaWQgKTogdm9pZCB7XG5cdFx0dGhpcy5jdmFPblRvdWNoZWQgPSBjYWxsYmFjaztcblx0fVxuXG5cdC8vIEltcGxlbWVudGluZyB0aGUgQ29udHJvbFZhbHVlQWNjZXNzb3IgaW50ZXJmYWNlIChvbmx5IHdoZW4gYmluZGluZyB0byBuZ01vZGVsKS5cblx0cHVibGljIHNldERpc2FibGVkU3RhdGUoIGlzRGlzYWJsZWQ6IGJvb2xlYW4gKTogdm9pZCB7XG5cdFx0Ly8gSWYgYWxyZWFkeSBpbml0aWFsaXplZC5cblx0XHRpZiAoIHRoaXMuZWRpdG9ySW5zdGFuY2UgKSB7XG5cdFx0XHRpZiAoIGlzRGlzYWJsZWQgKSB7XG5cdFx0XHRcdHRoaXMuZWRpdG9ySW5zdGFuY2UuZW5hYmxlUmVhZE9ubHlNb2RlKCBBTkdVTEFSX0lOVEVHUkFUSU9OX1JFQURfT05MWV9MT0NLX0lEICk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR0aGlzLmVkaXRvckluc3RhbmNlLmRpc2FibGVSZWFkT25seU1vZGUoIEFOR1VMQVJfSU5URUdSQVRJT05fUkVBRF9PTkxZX0xPQ0tfSUQgKTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQvLyBTdG9yZSB0aGUgc3RhdGUgYW55d2F5IHRvIHVzZSBpdCBvbmNlIHRoZSBlZGl0b3IgaXMgY3JlYXRlZC5cblx0XHR0aGlzLmluaXRpYWxseURpc2FibGVkID0gaXNEaXNhYmxlZDtcblx0fVxuXG5cdC8qKlxuXHQgKiBDcmVhdGVzIHRoZSBlZGl0b3IgaW5zdGFuY2UsIHNldHMgaW5pdGlhbCBlZGl0b3IgZGF0YSwgdGhlbiBpbnRlZ3JhdGVzXG5cdCAqIHRoZSBlZGl0b3Igd2l0aCB0aGUgQW5ndWxhciBjb21wb25lbnQuIFRoaXMgbWV0aG9kIGRvZXMgbm90IHVzZSB0aGUgYGVkaXRvci5kYXRhLnNldCgpYFxuXHQgKiBiZWNhdXNlIG9mIHRoZSBpc3N1ZSBpbiB0aGUgY29sbGFib3JhdGlvbiBtb2RlICgjNikuXG5cdCAqL1xuXHRwcml2YXRlIGF0dGFjaFRvV2F0Y2hkb2coKSB7XG5cdFx0Ly8gVE9ETzogZWxlbWVudE9yRGF0YSBwYXJhbWV0ZXIgdHlwZSBjYW4gYmUgc2ltcGxpZmllZCB0byBIVE1MRWxlbWVuIGFmdGVyIHRlbXBsYXRlZCBXYXRjaGRvZyB3aWxsIGJlIHJlbGVhc2VkLlxuXHRcdGNvbnN0IGNyZWF0b3IgPSAoICggZWxlbWVudE9yRGF0YTogSFRNTEVsZW1lbnQgfCBzdHJpbmcgfCBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LCBjb25maWc6IEVkaXRvckNvbmZpZyApID0+IHtcblx0XHRcdHJldHVybiB0aGlzLm5nWm9uZS5ydW5PdXRzaWRlQW5ndWxhciggYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHR0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5hcHBlbmRDaGlsZCggZWxlbWVudE9yRGF0YSBhcyBIVE1MRWxlbWVudCApO1xuXG5cdFx0XHRcdGNvbnN0IGVkaXRvciA9IGF3YWl0IHRoaXMuZWRpdG9yIS5jcmVhdGUoIGVsZW1lbnRPckRhdGEgYXMgSFRNTEVsZW1lbnQsIGNvbmZpZyApO1xuXG5cdFx0XHRcdGlmICggdGhpcy5pbml0aWFsbHlEaXNhYmxlZCApIHtcblx0XHRcdFx0XHRlZGl0b3IuZW5hYmxlUmVhZE9ubHlNb2RlKCBBTkdVTEFSX0lOVEVHUkFUSU9OX1JFQURfT05MWV9MT0NLX0lEICk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR0aGlzLm5nWm9uZS5ydW4oICgpID0+IHtcblx0XHRcdFx0XHR0aGlzLnJlYWR5LmVtaXQoIGVkaXRvciApO1xuXHRcdFx0XHR9ICk7XG5cblx0XHRcdFx0dGhpcy5zZXRVcEVkaXRvckV2ZW50cyggZWRpdG9yICk7XG5cblx0XHRcdFx0cmV0dXJuIGVkaXRvcjtcblx0XHRcdH0gKTtcblx0XHR9ICk7XG5cblx0XHRjb25zdCBkZXN0cnVjdG9yID0gYXN5bmMgKCBlZGl0b3I6IEVkaXRvciApID0+IHtcblx0XHRcdGF3YWl0IGVkaXRvci5kZXN0cm95KCk7XG5cblx0XHRcdHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnJlbW92ZUNoaWxkKCB0aGlzLmVkaXRvckVsZW1lbnQhICk7XG5cdFx0fTtcblxuXHRcdGNvbnN0IGVtaXRFcnJvciA9ICggZT86IHVua25vd24gKSA9PiB7XG5cdFx0XHQvLyBEbyBub3QgcnVuIGNoYW5nZSBkZXRlY3Rpb24gYnkgcmUtZW50ZXJpbmcgdGhlIEFuZ3VsYXIgem9uZSBpZiB0aGUgYGVycm9yYFxuXHRcdFx0Ly8gZW1pdHRlciBkb2Vzbid0IGhhdmUgYW55IHN1YnNjcmliZXJzLlxuXHRcdFx0Ly8gU3Vic2NyaWJlcnMgYXJlIHB1c2hlZCBvbnRvIHRoZSBsaXN0IHdoZW5ldmVyIGBlcnJvcmAgaXMgbGlzdGVuZWQgaW5zaWRlIHRoZSB0ZW1wbGF0ZTpcblx0XHRcdC8vIGA8Y2tlZGl0b3IgKGVycm9yKT1cIm9uRXJyb3IoLi4uKVwiPjwvY2tlZGl0b3I+YC5cblx0XHRcdGlmICggaGFzT2JzZXJ2ZXJzKCB0aGlzLmVycm9yICkgKSB7XG5cdFx0XHRcdHRoaXMubmdab25lLnJ1biggKCkgPT4gdGhpcy5lcnJvci5lbWl0KCBlICkgKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdGNvbnN0IGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCB0aGlzLnRhZ05hbWUgKTtcblx0XHRjb25zdCBjb25maWcgPSB0aGlzLmdldENvbmZpZygpO1xuXG5cdFx0dGhpcy5lZGl0b3JFbGVtZW50ID0gZWxlbWVudDtcblxuXHRcdC8vIEJhc2VkIG9uIHRoZSBwcmVzZW5jZSBvZiB0aGUgd2F0Y2hkb2cgZGVjaWRlIGhvdyB0byBpbml0aWFsaXplIHRoZSBlZGl0b3IuXG5cdFx0aWYgKCB0aGlzLndhdGNoZG9nICkge1xuXHRcdFx0Ly8gV2hlbiB0aGUgY29udGV4dCB3YXRjaGRvZyBpcyBwYXNzZWQgYWRkIHRoZSBuZXcgaXRlbSB0byBpdCBiYXNlZCBvbiB0aGUgcGFzc2VkIGNvbmZpZ3VyYXRpb24uXG5cdFx0XHR0aGlzLndhdGNoZG9nLmFkZCgge1xuXHRcdFx0XHRpZDogdGhpcy5pZCxcblx0XHRcdFx0dHlwZTogJ2VkaXRvcicsXG5cdFx0XHRcdGNyZWF0b3IsXG5cdFx0XHRcdGRlc3RydWN0b3IsXG5cdFx0XHRcdHNvdXJjZUVsZW1lbnRPckRhdGE6IGVsZW1lbnQsXG5cdFx0XHRcdGNvbmZpZ1xuXHRcdFx0fSApLmNhdGNoKCBlID0+IHtcblx0XHRcdFx0ZW1pdEVycm9yKCBlICk7XG5cdFx0XHR9ICk7XG5cblx0XHRcdHRoaXMud2F0Y2hkb2cub24oICdpdGVtRXJyb3InLCAoIF8sIHsgaXRlbUlkIH0gKSA9PiB7XG5cdFx0XHRcdGlmICggaXRlbUlkID09PSB0aGlzLmlkICkge1xuXHRcdFx0XHRcdGVtaXRFcnJvcigpO1xuXHRcdFx0XHR9XG5cdFx0XHR9ICk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIEluIHRoZSBvdGhlciBjYXNlIGNyZWF0ZSB0aGUgd2F0Y2hkb2cgYnkgaGFuZCB0byBrZWVwIHRoZSBlZGl0b3IgcnVubmluZy5cblx0XHRcdGNvbnN0IGVkaXRvcldhdGNoZG9nID0gbmV3IEVkaXRvcldhdGNoZG9nKFxuXHRcdFx0XHR0aGlzLmVkaXRvciEsXG5cdFx0XHRcdHRoaXMuZWRpdG9yV2F0Y2hkb2dDb25maWcgKTtcblxuXHRcdFx0ZWRpdG9yV2F0Y2hkb2cuc2V0Q3JlYXRvciggY3JlYXRvciApO1xuXHRcdFx0ZWRpdG9yV2F0Y2hkb2cuc2V0RGVzdHJ1Y3RvciggZGVzdHJ1Y3RvciApO1xuXHRcdFx0ZWRpdG9yV2F0Y2hkb2cub24oICdlcnJvcicsIGVtaXRFcnJvciApO1xuXG5cdFx0XHR0aGlzLmVkaXRvcldhdGNoZG9nID0gZWRpdG9yV2F0Y2hkb2c7XG5cdFx0XHR0aGlzLm5nWm9uZS5ydW5PdXRzaWRlQW5ndWxhciggKCkgPT4ge1xuXHRcdFx0XHQvLyBOb3RlOiBtdXN0IGJlIGNhbGxlZCBvdXRzaWRlIG9mIHRoZSBBbmd1bGFyIHpvbmUgdG9vIGJlY2F1c2UgYGNyZWF0ZWAgaXMgY2FsbGluZ1xuXHRcdFx0XHQvLyBgX3N0YXJ0RXJyb3JIYW5kbGluZ2Agd2l0aGluIGEgbWljcm90YXNrIHdoaWNoIHNldHMgdXAgYGVycm9yYCBsaXN0ZW5lciBvbiB0aGUgd2luZG93LlxuXHRcdFx0XHRlZGl0b3JXYXRjaGRvZy5jcmVhdGUoIGVsZW1lbnQsIGNvbmZpZyApLmNhdGNoKCBlID0+IHtcblx0XHRcdFx0XHRlbWl0RXJyb3IoIGUgKTtcblx0XHRcdFx0fSApO1xuXHRcdFx0fSApO1xuXHRcdH1cblx0fVxuXG5cdHByaXZhdGUgZ2V0Q29uZmlnKCkge1xuXHRcdGlmICggdGhpcy5kYXRhICYmIHRoaXMuY29uZmlnLmluaXRpYWxEYXRhICkge1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKCAnRWRpdG9yIGRhdGEgc2hvdWxkIGJlIHByb3ZpZGVkIGVpdGhlciB1c2luZyBgY29uZmlnLmluaXRpYWxEYXRhYCBvciBgZGF0YWAgcHJvcGVydGllcy4nICk7XG5cdFx0fVxuXG5cdFx0Y29uc3QgY29uZmlnID0geyAuLi50aGlzLmNvbmZpZyB9O1xuXG5cdFx0Ly8gTWVyZ2UgdHdvIHBvc3NpYmxlIHdheXMgb2YgcHJvdmlkaW5nIGRhdGEgaW50byB0aGUgYGNvbmZpZy5pbml0aWFsRGF0YWAgZmllbGQuXG5cdFx0Y29uc3QgaW5pdGlhbERhdGEgPSB0aGlzLmNvbmZpZy5pbml0aWFsRGF0YSB8fCB0aGlzLmRhdGE7XG5cblx0XHRpZiAoIGluaXRpYWxEYXRhICkge1xuXHRcdFx0Ly8gRGVmaW5lIHRoZSBgY29uZmlnLmluaXRpYWxEYXRhYCBvbmx5IHdoZW4gdGhlIGluaXRpYWwgY29udGVudCBpcyBzcGVjaWZpZWQuXG5cdFx0XHRjb25maWcuaW5pdGlhbERhdGEgPSBpbml0aWFsRGF0YTtcblx0XHR9XG5cblx0XHRyZXR1cm4gY29uZmlnO1xuXHR9XG5cblx0LyoqXG5cdCAqIEludGVncmF0ZXMgdGhlIGVkaXRvciB3aXRoIHRoZSBjb21wb25lbnQgYnkgYXR0YWNoaW5nIHJlbGF0ZWQgZXZlbnQgbGlzdGVuZXJzLlxuXHQgKi9cblx0cHJpdmF0ZSBzZXRVcEVkaXRvckV2ZW50cyggZWRpdG9yOiBURWRpdG9yICk6IHZvaWQge1xuXHRcdGNvbnN0IG1vZGVsRG9jdW1lbnQgPSBlZGl0b3IubW9kZWwuZG9jdW1lbnQ7XG5cdFx0Y29uc3Qgdmlld0RvY3VtZW50ID0gZWRpdG9yLmVkaXRpbmcudmlldy5kb2N1bWVudDtcblxuXHRcdG1vZGVsRG9jdW1lbnQub248RG9jdW1lbnRDaGFuZ2VFdmVudD4oICdjaGFuZ2U6ZGF0YScsIGV2dCA9PiB7XG5cdFx0XHR0aGlzLm5nWm9uZS5ydW4oICgpID0+IHtcblx0XHRcdFx0aWYgKCB0aGlzLmRpc2FibGVUd29XYXlEYXRhQmluZGluZyApIHtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAoIHRoaXMuY3ZhT25DaGFuZ2UgJiYgIXRoaXMuaXNFZGl0b3JTZXR0aW5nRGF0YSApIHtcblx0XHRcdFx0XHRjb25zdCBkYXRhID0gZWRpdG9yLmRhdGEuZ2V0KCk7XG5cblx0XHRcdFx0XHR0aGlzLmN2YU9uQ2hhbmdlKCBkYXRhICk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR0aGlzLmNoYW5nZS5lbWl0KCB7IGV2ZW50OiBldnQsIGVkaXRvciB9ICk7XG5cdFx0XHR9ICk7XG5cdFx0fSApO1xuXG5cdFx0dmlld0RvY3VtZW50Lm9uPFZpZXdEb2N1bWVudEZvY3VzRXZlbnQ+KCAnZm9jdXMnLCBldnQgPT4ge1xuXHRcdFx0dGhpcy5uZ1pvbmUucnVuKCAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuZm9jdXMuZW1pdCggeyBldmVudDogZXZ0LCBlZGl0b3IgfSApO1xuXHRcdFx0fSApO1xuXHRcdH0gKTtcblxuXHRcdHZpZXdEb2N1bWVudC5vbjxWaWV3RG9jdW1lbnRCbHVyRXZlbnQ+KCAnYmx1cicsIGV2dCA9PiB7XG5cdFx0XHR0aGlzLm5nWm9uZS5ydW4oICgpID0+IHtcblx0XHRcdFx0aWYgKCB0aGlzLmN2YU9uVG91Y2hlZCApIHtcblx0XHRcdFx0XHR0aGlzLmN2YU9uVG91Y2hlZCgpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0dGhpcy5ibHVyLmVtaXQoIHsgZXZlbnQ6IGV2dCwgZWRpdG9yIH0gKTtcblx0XHRcdH0gKTtcblx0XHR9ICk7XG5cdH1cbn1cblxuZnVuY3Rpb24gaGFzT2JzZXJ2ZXJzPFQ+KCBlbWl0dGVyOiBFdmVudEVtaXR0ZXI8VD4gKTogYm9vbGVhbiB7XG5cdC8vIENhc3QgdG8gYGFueWAgYmVjYXVzZSBgb2JzZXJ2ZWRgIHByb3BlcnR5IGlzIGF2YWlsYWJsZSBpbiBSeEpTID49IDcuMi4wLlxuXHQvLyBGYWxsYmFjayB0byBjaGVja2luZyBgb2JzZXJ2ZXJzYCBsaXN0IGlmIHRoaXMgcHJvcGVydHkgaXMgbm90IGRlZmluZWQuXG5cdHJldHVybiAoIGVtaXR0ZXIgYXMgYW55ICkub2JzZXJ2ZWQgfHwgZW1pdHRlci5vYnNlcnZlcnMubGVuZ3RoID4gMDtcbn1cbiJdfQ==