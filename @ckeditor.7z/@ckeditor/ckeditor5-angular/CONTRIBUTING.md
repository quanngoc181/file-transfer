Contributing
========================================

See the [official contributors' guide to CKEditor 5](https://ckeditor.com/docs/ckeditor5/latest/framework/guides/contributing/contributing.html) to learn more about the general rules followed by the CKEditor 5 core team.

See also the [Contributing](https://github.com/ckeditor/ckeditor5-angular#contributing) section of this specific package to learn more about contributing to this package.
