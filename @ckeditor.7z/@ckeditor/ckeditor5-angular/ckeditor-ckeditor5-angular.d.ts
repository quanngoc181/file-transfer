/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@ckeditor/ckeditor5-angular" />
export * from './index';
