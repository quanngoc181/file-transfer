const csv = require('csvtojson');

async function execute() {
    console.log('hello')

    let products = await csv({
        noheader: false,
        trim: true,
    })
        .fromFile('.\\data\\vietcuong_product.csv');
    console.log(products[0]);

    let actproducts = await csv({
        noheader: true,
        trim: true,
        headers: ['ID', 'ProductCode', 'ProductName']
    })
        .fromFile('.\\data\\vietcuong_product_act.csv');
    console.log(actproducts[0]);

    // Lấy danh sách product code
    let codes = products.map(p => p.ProductCode);
    let distinctCodes = [...new Set(codes)];
    console.log(distinctCodes.length);

    let keepIDs = [];
    let inactiveIDs = [];

    for (const code of distinctCodes) {
        // Lấy những product trùng mã
        let dups = products.filter(p => p.ProductCode === code);
        if (dups.length < 2) continue;

        let keep = null;

        // tìm trong act product với mã đó
        let actProduct = actproducts.find(p => p.ProductCode === code);
        if (actProduct) {
            let dupsClone = JSON.parse(JSON.stringify(dups));
            // Lấy những hàng hóa trùng tên với act
            let keeps = dupsClone.filter(p => p.ProductName === actProduct.ProductName);
            if (keeps.length) {
                keeps.sort((a, b) => new Date(b.ModifiedDate).getTime() - new Date(a.ModifiedDate).getTime());
                keep = keeps[0];
            } else {
                dupsClone.sort((a, b) => new Date(b.ModifiedDate).getTime() - new Date(a.ModifiedDate).getTime());
                keep = dupsClone[0];
            }
            console.log(code, 'có', keeps.length, 'trùng tên', '=> lấy', keep.ID);
        } else {
            let dupsClone = JSON.parse(JSON.stringify(dups));
            dupsClone.sort((a, b) => new Date(b.ModifiedDate).getTime() - new Date(a.ModifiedDate).getTime());
            keep = dupsClone[0];
            console.log(code, 'có', 0, 'act product', '=> lấy', keep.ID);
        }

        keepIDs.push(Number(keep.ID));
    }

    console.log(keepIDs.length, JSON.stringify(keepIDs));
}

execute();